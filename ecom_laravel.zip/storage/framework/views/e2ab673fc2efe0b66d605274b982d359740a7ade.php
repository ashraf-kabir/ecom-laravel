<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="limiter">
  <div class="container-login100" style="background-image: url('frontend/login/images/bg-01.jpg');">
    <div class="wrap-login100">

      <?php if(Session::has('msg')): ?>
        <div class="alert alert-danger">
          <?php echo e(Session::get('msg')); ?>

        </div>
      <?php endif; ?>

      <?php if(Session::has('error')): ?>
        <div class="alert alert-danger">
          <?php echo e(Session::get('error')); ?>

        </div>
      <?php endif; ?>

      <?php if(count($errors) > 0): ?>
        <div class="alert alert-success">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form class="login100-form validate-form" method="POST" action="<?php echo e(url('/login_account')); ?>">
        <?php echo e(csrf_field()); ?>

        <a href="<?php echo e(URL::to('/')); ?>">
          <span class="login100-form-logo">
            <i class="zmdi zmdi-landscape"></i>
          </span>
        </a>

        <span class="login100-form-title p-b-34 p-t-27">
          Log in
        </span>

        <div class="wrap-input100 validate-input" data-validate = "Enter email">
          <input class="input100" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" />
          <span class="focus-input100" data-placeholder="&#xf207;"></span>
        </div>

        <div class="wrap-input100 validate-input" data-validate="Enter password">
          <input class="input100" type="password" name="password" placeholder="Password" autocomplete="off" />
          <span class="focus-input100" data-placeholder="&#xf191;"></span>
        </div>

        

        <div class="container-login100-form-btn">
          <button class="login100-form-btn">
            Login
          </button>
        </div>

        <div class="text-center p-t-90">
          <a class="txt1" href="/signup">
            Don't have an account? Signup
          </a>
        </div>

        

      </form>
    </div>
  </div>
</div>


<div id="dropDownSelect1"></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecom-laravel/resources/views/client/login.blade.php ENDPATH**/ ?>