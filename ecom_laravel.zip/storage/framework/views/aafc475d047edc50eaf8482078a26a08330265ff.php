<?php $__env->startSection('title'); ?>
    Edit Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
  <div class="row grid-margin">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Edit Product</h4>

          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>

          <?php echo Form::open(['action' => ['App\Http\Controllers\ProductController@update', $product->id], 'class' => 'edit_product_form', 'method' => 'PUT', 'enctype' => 'multipart', 'files' => true]); ?>

            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <?php echo e(Form::label('', 'Product Name', ['for' => 'product_name'])); ?>

                <?php echo e(Form::text('product_name', $product->product_name, ['class' => 'form-control', 'minlength' => '2', 'id' => 'product_name'])); ?>

              </div>

              <div class="form-group">
                <?php echo e(Form::label('', 'Product Price', ['for' => 'product_price'])); ?>

                <?php echo e(Form::text('product_price', $product->product_price, ['class' => 'form-control', 'id' => 'product_price'])); ?>

              </div>

              <div class="form-group">
                <?php echo e(Form::label('', 'Product Category', ['for' => 'product_category'])); ?>

                <?php echo e(Form::select('category_id', $categories, $product->category->id, ['class' => 'form-control', 'id' => 'product_category'])); ?>

              </div>

              <div class="form-group">
                <?php echo e(Form::label('', 'Product Image', ['for' => 'product_image'])); ?>


                <div class="row ml-2 mb-1">
                  <img class="float-right" src="<?php echo e(asset($product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" width="50" height="50">
                </div>

                <?php echo e(Form::file('product_image', ['class' => 'form-control', 'id' => 'product_image'])); ?>

              </div>

              

              <?php echo e(Form::submit('Update', ['class' => 'btn btn-success'])); ?>

          <?php echo Form::close(); ?>


        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="js/bt-maxLength.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecom-laravel/resources/views/admin/editproduct.blade.php ENDPATH**/ ?>