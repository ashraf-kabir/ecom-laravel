<?php $__env->startSection('title'); ?>
    Add Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
  <div class="row grid-margin">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Create Slider</h4>

          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>

          <?php echo Form::open(['action' => 'App\Http\Controllers\SliderController@store', 'class' => 'create_slider_form', 'method' => 'POST', 'id' => 'create_slider_form', 'enctype' => 'multipart', 'files' => true]); ?>

            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <?php echo e(Form::label('', 'Description One', ['for' => 'description_one'])); ?>

                <?php echo e(Form::text('description_one', '', ['class' => 'form-control', 'id' => 'description_one', 'minlength' => '5'])); ?>

              </div>

              <div class="form-group">
                <?php echo e(Form::label('', 'Description Two', ['for' => 'description_two'])); ?>

                <?php echo e(Form::text('description_two', '', ['class' => 'form-control', 'id' => 'description_two', 'minlength' => '5'])); ?>

              </div>

              <div class="form-group">
                <?php echo e(Form::label('', 'Slider Image', ['for' => 'slider_image'])); ?>

                <?php echo e(Form::file('slider_image', ['class' => 'form-control', 'id' => 'slider_image'])); ?>

              </div>

              

              <?php echo e(Form::submit('Save', ['class' => 'btn btn-success'])); ?>

          <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('admin/js/bt-maxLength.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecom-laravel/resources/views/admin/addslider.blade.php ENDPATH**/ ?>