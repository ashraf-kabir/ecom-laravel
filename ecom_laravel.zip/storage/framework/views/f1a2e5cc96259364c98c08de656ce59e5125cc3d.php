<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="card">
  <div class="card-body">
    <h4 class="card-title">Categories</h4>

    <?php if(Session::has('status_1')): ?>
      <div class="alert alert-success">
        <?php echo e(Session::get('status_1')); ?>

      </div>
    <?php endif; ?>

    <?php if(Session::has('status_2')): ?>
      <div class="alert alert-danger">
        <?php echo e(Session::get('status_2')); ?>

      </div>
    <?php endif; ?>

    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table id="order-listing" class="table">
            <thead>
              <tr>
                  <th>ID #</th>
                  <th>Category Name</th>
                  <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($category->id); ?></td>
                  <td><?php echo e($category->category_name); ?></td>
                  <td>
                    <button class="btn btn-outline-primary" onclick="window.location = '<?php echo e(url('admin/category/edit/'.$category->id)); ?>'">Edit</button>
                    <a class="btn btn-outline-danger" href="/admin/category/delete/<?php echo e($category->id); ?>" id="delete">Delete</a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('admin/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecom-laravel/resources/views/admin/categories.blade.php ENDPATH**/ ?>