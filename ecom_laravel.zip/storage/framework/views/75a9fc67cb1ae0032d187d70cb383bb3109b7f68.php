<?php $__env->startSection('title'); ?>
    Add Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
  <div class="row grid-margin">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Create Category</h4>

          <?php if(Session::has('status_1')): ?>
            <div class="alert alert-success">
              <?php echo e(Session::get('status_1')); ?>

            </div>
          <?php endif; ?>

          <?php if(Session::has('status_2')): ?>
            <div class="alert alert-danger">
              <?php echo e(Session::get('status_2')); ?>

            </div>
          <?php endif; ?>

          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>

          <?php echo Form::open(['action' => 'App\Http\Controllers\CategoryController@store', 'class' => 'add_category_form', 'method' => 'POST', 'id' => 'add_category_form']); ?>

            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <?php echo e(Form::label('', 'Category Name', ['for' => 'category_name'])); ?>

                <?php echo e(Form::text('category_name', '', ['class' => 'form-control', 'minlength' => '2', 'id' => 'category_name'])); ?>

              </div>
              <?php echo e(Form::submit('Save', ['class' => 'btn btn-success'])); ?>

          <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('admin/js/bt-maxLength.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecom-laravel/resources/views/admin/addcategory.blade.php ENDPATH**/ ?>