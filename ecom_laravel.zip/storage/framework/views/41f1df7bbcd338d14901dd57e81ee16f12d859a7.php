<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="card">
  <div class="card-body">
    <h4 class="card-title">Products</h4>

    <?php if(Session::has('status_1')): ?>
      <div class="alert alert-success">
        <?php echo e(Session::get('status_1')); ?>

      </div>
    <?php endif; ?>

    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table id="order-listing" class="table">
            <thead>
              <tr>
                  <th>ID #</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Category</th>
                  <th>Image</th>
                  <th>Status</th>
                  <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($product->id); ?></td>
                  <td><?php echo e($product->product_name); ?></td>
                  <td>$<?php echo e($product->product_price); ?></td>
                  <td><?php echo e($product->category->category_name); ?></td>
                  <td><img src="<?php echo e(asset($product->product_image)); ?>" alt="<?php echo e($product->product_name); ?>" width="50" height="50"></td>
                  <td>
                    <?php if($product->status == 1): ?>
                      <label class="badge badge-success">Activated</label>
                    <?php else: ?>
                      <label class="badge badge-danger">Deactivated</label>
                    <?php endif; ?>
                  </td>
                  <td>
                    <button class="btn btn-outline-primary" onclick="window.location = '<?php echo e(url('admin/product/edit/'.$product->id)); ?>'">Edit</button>
                    <a class="btn btn-outline-danger" href="/admin/product/delete/<?php echo e($product->id); ?>" id="delete">Delete</a>
                    <?php if($product->status == 1): ?>
                      <button class="btn btn-outline-warning" onclick="window.location = '<?php echo e(url('admin/product/deactivate/'.$product->id)); ?>'">Deactivate</button>                    
                    <?php else: ?>
                      <button class="btn btn-outline-success" onclick="window.location = '<?php echo e(url('admin/product/activate/'.$product->id)); ?>'">Activate</button>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('admin/js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecom-laravel/resources/views/admin/products.blade.php ENDPATH**/ ?>